#include "uart_read_line_sensor.h"

namespace uart_read_line_sensor {

// Nothing needed here for now

}
